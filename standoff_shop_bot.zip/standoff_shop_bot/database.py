import aiosqlite
import datetime
from config import DB_PATH

CREATE_USERS = """
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    full_name TEXT,
    source TEXT DEFAULT 'direct',
    referrer_id INTEGER,
    balance REAL DEFAULT 0,
    reg_date TEXT
)
"""

CREATE_WITHDRAWALS = """
CREATE TABLE IF NOT EXISTS withdrawals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    amount REAL,
    requisites TEXT,
    status TEXT DEFAULT 'pending',
    created_at TEXT
)
"""

CREATE_PURCHASES = """
CREATE TABLE IF NOT EXISTS purchases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    product_id TEXT,
    product_title TEXT,
    method TEXT,
    amount TEXT,
    status TEXT DEFAULT 'pending',
    receipt_file_id TEXT,
    created_at TEXT
)
"""


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(CREATE_USERS)
        await db.execute(CREATE_PURCHASES)
        await db.execute(CREATE_WITHDRAWALS)
        await db.commit()


async def add_user(user_id: int, username: str, full_name: str, source: str = "direct", referrer_id: int = None):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT user_id FROM users WHERE user_id = ?", (user_id,))
        row = await cur.fetchone()
        if row is None:
            await db.execute(
                "INSERT INTO users (user_id, username, full_name, source, referrer_id, reg_date) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (user_id, username, full_name, source, referrer_id, datetime.datetime.utcnow().isoformat()),
            )
            await db.commit()
            return True  # новый пользователь
        return False  # уже был в базе


async def get_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        return await cur.fetchone()


async def get_all_user_ids():
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT user_id FROM users")
        rows = await cur.fetchall()
        return [r[0] for r in rows]


async def get_stats():
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT COUNT(*) FROM users")
        total = (await cur.fetchone())[0]

        cur = await db.execute(
            "SELECT source, COUNT(*) FROM users GROUP BY source ORDER BY COUNT(*) DESC"
        )
        by_source = await cur.fetchall()

        cur = await db.execute(
            "SELECT COUNT(*) FROM purchases WHERE status = 'confirmed'"
        )
        sales = (await cur.fetchone())[0]

        return {"total_users": total, "by_source": by_source, "sales": sales}


async def create_purchase(user_id: int, product_id: str, product_title: str, method: str, amount: str) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "INSERT INTO purchases (user_id, product_id, product_title, method, amount, status, created_at) "
            "VALUES (?, ?, ?, ?, ?, 'pending', ?)",
            (user_id, product_id, product_title, method, amount, datetime.datetime.utcnow().isoformat()),
        )
        await db.commit()
        return cur.lastrowid


async def attach_receipt(purchase_id: int, file_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE purchases SET receipt_file_id = ? WHERE id = ?", (file_id, purchase_id)
        )
        await db.commit()


async def set_purchase_status(purchase_id: int, status: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE purchases SET status = ? WHERE id = ?", (status, purchase_id)
        )
        await db.commit()


async def get_purchase(purchase_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM purchases WHERE id = ?", (purchase_id,))
        return await cur.fetchone()


# ---------------------------------------------------------------------------
# Реферальная система
# ---------------------------------------------------------------------------
async def get_referral_stats(user_id: int) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        row = await cur.fetchone()
        balance = row[0] if row else 0

        cur = await db.execute(
            "SELECT COUNT(*) FROM users WHERE referrer_id = ?", (user_id,)
        )
        referrals_count = (await cur.fetchone())[0]

        return {"balance": balance, "referrals_count": referrals_count}


async def credit_referral(referred_user_id: int, purchase_amount_rub: float, percent: int) -> float | None:
    """Начисляет проценты рефереру пользователя referred_user_id. Возвращает начисленную сумму либо None."""
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT referrer_id FROM users WHERE user_id = ?", (referred_user_id,)
        )
        row = await cur.fetchone()
        if not row or row[0] is None:
            return None

        referrer_id = row[0]
        amount = round(purchase_amount_rub * percent / 100, 2)

        await db.execute(
            "UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, referrer_id)
        )
        await db.commit()
        return amount


async def create_withdrawal(user_id: int, amount: float, requisites: str) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "INSERT INTO withdrawals (user_id, amount, requisites, status, created_at) "
            "VALUES (?, ?, ?, 'pending', ?)",
            (user_id, amount, requisites, datetime.datetime.utcnow().isoformat()),
        )
        await db.commit()
        return cur.lastrowid


async def get_withdrawal(withdrawal_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM withdrawals WHERE id = ?", (withdrawal_id,))
        return await cur.fetchone()


async def set_withdrawal_status(withdrawal_id: int, status: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE withdrawals SET status = ? WHERE id = ?", (status, withdrawal_id)
        )
        await db.commit()


async def deduct_balance(user_id: int, amount: float):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET balance = balance - ? WHERE user_id = ?", (amount, user_id)
        )
        await db.commit()
