import asyncio
from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery

import database as db
from config import ADMIN_IDS, PRODUCTS
from keyboards import admin_panel_kb, back_to_menu_kb

router = Router()


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


class BroadcastState(StatesGroup):
    waiting_message = State()


@router.message(Command("admin"))
async def cmd_admin(message: Message):
    if not is_admin(message.from_user.id):
        return
    await message.answer("🛠 Админ-панель", reply_markup=admin_panel_kb())


@router.callback_query(F.data == "admin:stats")
async def cb_admin_stats(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        await call.answer("Недостаточно прав", show_alert=True)
        return

    stats = await db.get_stats()
    lines = [
        "📊 <b>Статистика</b>\n",
        f"Всего пользователей: {stats['total_users']}",
        f"Подтверждённых продаж: {stats['sales']}\n",
        "<b>Источники трафика:</b>",
    ]
    if stats["by_source"]:
        for source, count in stats["by_source"]:
            lines.append(f"• {source}: {count}")
    else:
        lines.append("нет данных")

    await call.message.edit_text("\n".join(lines), reply_markup=admin_panel_kb())
    await call.answer()


@router.callback_query(F.data == "admin:broadcast")
async def cb_admin_broadcast(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        await call.answer("Недостаточно прав", show_alert=True)
        return

    await state.set_state(BroadcastState.waiting_message)
    await call.message.edit_text(
        "✏️ Пришлите сообщение (текст/фото/видео) для рассылки всем пользователям.\n"
        "Для отмены — /admin"
    )
    await call.answer()


@router.message(BroadcastState.waiting_message)
async def do_broadcast(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return

    await state.clear()
    user_ids = await db.get_all_user_ids()
    await message.answer(f"⏳ Начинаю рассылку на {len(user_ids)} пользователей...")

    sent, failed = 0, 0
    for uid in user_ids:
        try:
            await message.copy_to(uid)
            sent += 1
        except Exception:
            failed += 1
        await asyncio.sleep(0.05)  # чтобы не упереться в лимиты Telegram

    await message.answer(f"✅ Рассылка завершена.\nДоставлено: {sent}\nОшибок: {failed}")


# ---------------------------------------------------------------------------
# Подтверждение / отклонение оплаты картой
# ---------------------------------------------------------------------------
@router.callback_query(F.data.startswith("admin_confirm:"))
async def cb_admin_confirm(call: CallbackQuery, bot: Bot):
    if not is_admin(call.from_user.id):
        await call.answer("Недостаточно прав", show_alert=True)
        return

    purchase_id = int(call.data.split(":", 1)[1])
    purchase = await db.get_purchase(purchase_id)
    if purchase is None:
        await call.answer("Заявка не найдена", show_alert=True)
        return

    await db.set_purchase_status(purchase_id, "confirmed")
    product = next((p for p in PRODUCTS if p["id"] == purchase["product_id"]), None)

    try:
        await bot.send_message(
            purchase["user_id"],
            f"✅ Оплата подтверждена!\n\n{product['delivery'] if product else 'Ваш товар выдан.'}",
        )
    except Exception:
        pass

    await call.message.edit_caption(
        caption=(call.message.caption or "") + "\n\n✅ ПОДТВЕРЖДЕНО"
    )
    await call.answer("Подтверждено")


@router.callback_query(F.data.startswith("admin_reject:"))
async def cb_admin_reject(call: CallbackQuery, bot: Bot):
    if not is_admin(call.from_user.id):
        await call.answer("Недостаточно прав", show_alert=True)
        return

    purchase_id = int(call.data.split(":", 1)[1])
    purchase = await db.get_purchase(purchase_id)
    if purchase is None:
        await call.answer("Заявка не найдена", show_alert=True)
        return

    await db.set_purchase_status(purchase_id, "rejected")

    try:
        await bot.send_message(
            purchase["user_id"],
            "❌ Оплата не подтверждена. Если вы уверены, что оплатили корректно, "
            "обратитесь в поддержку и приложите чек ещё раз.",
        )
    except Exception:
        pass

    await call.message.edit_caption(
        caption=(call.message.caption or "") + "\n\n❌ ОТКЛОНЕНО"
    )
    await call.answer("Отклонено")
